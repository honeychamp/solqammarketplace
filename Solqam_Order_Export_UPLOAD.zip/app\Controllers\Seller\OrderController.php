<?php

namespace App\Controllers\Seller;

use App\Controllers\BaseController;
use App\Models\OrderItemModel;
use App\Models\OrderModel;
use App\Services\Order\OrderService;

class OrderController extends BaseController
{
    protected OrderModel $orderModel;
    protected OrderItemModel $orderItemModel;
    protected OrderService $orderService;

    public function __construct()
    {
        $this->orderModel     = new OrderModel();
        $this->orderItemModel = new OrderItemModel();
        $this->orderService   = new OrderService();
    }

    public function index()
    {
        $sellerId = (int) session()->get('user.id');
        $items = $this->orderItemModel->getSellerOrderItems($sellerId);
        [$items, $pager] = hub_paginate_array($items, 25);

        return view('seller/orders/index', [
            'title' => 'Incoming Orders — Solqam Seller Hub',
            'items' => $items,
            'pager' => $pager,
        ]);
    }

    public function export()
    {
        try {
            $sellerId = (int) session()->get('user.id');
            $svc = new \App\Services\Export\OrderExportService();
            $filters = $svc->filtersFromRequest($this->request, $sellerId);
            $stamp = date('Ymd_His');

            return $svc->download($filters, $sellerId, 'Solqam_Store_Orders_' . $stamp);
        } catch (\Throwable $e) {
            log_message('error', 'Seller order export: ' . $e->getMessage());

            return redirect()->to(site_url('seller/orders'))->with('error', 'Export failed. Please try CSV.');
        }
    }

    public function show($orderId)
    {
        $sellerId = (int) session()->get('user.id');
        $order = $this->orderModel->getOrderDetail((int) $orderId);

        if (!$order) {
            return redirect()->to('/seller/orders')->with('error', 'Order not found.');
        }

        // Filter items to show seller's items
        $sellerItems = array_filter($order['items'], fn($it) => (int) $it['seller_id'] === $sellerId);
        if (empty($sellerItems)) {
            return redirect()->to('/seller/orders')->with('error', 'Access denied.');
        }

        $shipment = null;
        foreach ($order['shipments'] ?? [] as $pkg) {
            if ((int) $pkg['seller_id'] === $sellerId) {
                $shipment = $pkg;
                break;
            }
        }

        return view('seller/orders/detail', [
            'title'       => "Order {$order['order_number']} — Solqam Seller Hub",
            'order'       => $order,
            'sellerItems' => $sellerItems,
            'shipment'    => $shipment,
        ]);
    }

    public function updateStatus($orderId)
    {
        $sellerId = (int) session()->get('user.id');
        $order = $this->orderModel->find((int) $orderId);

        if (!$order) {
            return redirect()->to('/seller/orders')->with('error', 'Order not found.');
        }

        $newStatus = $this->request->getPost('status');
        $sellerAllowedStatuses = ['confirmed', 'shipped', 'delivered', 'undelivered'];
        if (!in_array($newStatus, $sellerAllowedStatuses, true)) {
            return redirect()->back()->with('error', 'Invalid status. Use Confirmed, Shipped, Delivered, or Not received.');
        }

        try {
            $this->orderService->updateSellerShipment((int) $orderId, $sellerId, $newStatus, [
                'tracking_number' => $this->request->getPost('tracking_number'),
                'courier'         => $this->request->getPost('courier'),
            ]);
            return $this->redirectAfterHub('/seller/orders/' . $orderId, 'success', 'Your package status is now ' . ucfirst($newStatus));
        } catch (\Exception $e) {
            return $this->redirectAfterHub('/seller/orders/' . $orderId, 'error', $e->getMessage());
        }
    }

    public function setFulfill($orderId)
    {
        $sellerId = (int) session()->get('user.id');
        $by       = (string) $this->request->getPost('fulfill_by');
        try {
            $this->orderService->setFulfillBy((int) $orderId, $sellerId, $by);
            $msg = $by === 'admin'
                ? 'Package assigned to Solqam delivery. Send the parcel to Solqam. Admin will deliver and keep the delivery fee.'
                : 'You will deliver this package. After delivery you keep the delivery fee; category commission still goes to Solqam.';

            return $this->redirectAfterHub('/seller/orders/' . $orderId, 'success', $msg);
        } catch (\Exception $e) {
            return $this->redirectAfterHub('/seller/orders/' . $orderId, 'error', $e->getMessage());
        }
    }

    public function slip($orderId)
    {
        $sellerId = (int) session()->get('user.id');
        $order = $this->orderModel->getOrderDetail((int) $orderId);
        if (! $order) {
            return redirect()->to('/seller/orders')->with('error', 'Order not found.');
        }
        $sellerItems = array_filter($order['items'], fn ($it) => (int) $it['seller_id'] === $sellerId);
        if ($sellerItems === []) {
            return redirect()->to('/seller/orders')->with('error', 'Access denied.');
        }

        return view('seller/orders/slip', [
            'title'       => 'Packing slip ' . $order['order_number'],
            'order'       => $order,
            'sellerItems' => $sellerItems,
        ]);
    }
}
